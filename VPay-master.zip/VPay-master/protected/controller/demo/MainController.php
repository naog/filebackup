<?php
namespace controller\demo;
class MainController extends BaseController
{
    // 首页
    function actionIndex(){

    }

}