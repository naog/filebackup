<?php

/*
 * (c) Jeroen van den Enden <info@endroid.nl>
 *
 * This source file is subject to the MIT license that is bundled
 * with this source code in the file LICENSE.
 */

namespace Endroid\QrCode\Tests\Bundle;

use PHPUnit\Framework\TestCase;

class EndroidQrCodeBundleTest extends TestCase
{
    public function testNoTestsYet()
    {
        $this->assertTrue(true);
    }
}
