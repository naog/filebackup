<?php
/**
 * 1.php
 * User: Dreamn
 * Date: 2020/1/6 1:21
 * Description:
 */
namespace Speed;
namespace lib\json;
class Services_JSON_Error
{
    function Services_JSON_Error($message = 'unknown error', $code = null,
                                 $mode = null, $options = null, $userinfo = null)
    {
    }
}